import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

// Components
import Header from "./components/Header/page";
import Navbar from "./components/Navbar/page";
import Footer from "./components/Footer/page";

// Pages
// Home component moved below
import Dashboard from "./pages/Dashboard/page";
import Destinations from "./pages/Destinations/page";
import Features from "./pages/Features/page";
import Login from "./pages/Login/page";
import Signup from "./pages/Signup/page";

import "./index.css";

export default function App() {
  return (
    <Router>
      <Header />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/destinations" element={<Destinations />} />
        <Route path="/features" element={<Features />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
      </Routes>
      <Footer />
    </Router>
  );
}

function Home() {
  return (
    <main className="container">
      <div className="hero-banner">
        <h2>🌍 Explore the World with WanderLog</h2>
        <p>Your ultimate travel companion for discovering hidden gems and sharing unforgettable experiences.</p>
        <Link to="/destinations" className="btn btn-outline">View Destination Details</Link>
      </div>

      <div className="stats-row">
        <div className="stat-box">
          <span className="stat-number">120+</span>
          <span className="stat-label">Destinations Listed</span>
        </div>
        <div className="stat-box">
          <span className="stat-number">5,400</span>
          <span className="stat-label">Happy Travelers</span>
        </div>
        <div className="stat-box">
          <span className="stat-number">320</span>
          <span className="stat-label">Blog Posts</span>
        </div>
      </div>

      <div className="section-heading">
        <h2>Featured Destinations</h2>
        <p>Top picks from our travel experts for this season</p>
      </div>

      <section className="card-grid">
        <article className="card-item">
          <img src="/images/image4.png" alt="Hunza" className="card-image-styled" />
          <div className="card-body">
            <span className="category-tag">NORTH</span>
            <h3>Explore Hunza</h3>
            <p>Towering peaks and ancient forts.</p>
            <Link to="/destinations" className="btn btn-small">View Details</Link>
          </div>
        </article>
        {/* Add more articles as per your original index.html */}
      </section>
    </main>
  );
}