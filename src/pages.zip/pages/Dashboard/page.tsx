export default function Dashboard() {
  return (
    /* This main wrapper triggers the flexbox layout in your CSS */
    <div className="dashboard-layout">
      
      {/* SIDEBAR SECTION */}
      <aside className="sidebar">
        <p className="sidebar-title">Menu</p>
        <a href="#" className="sidebar-link active">Overview</a>
        
        <p className="sidebar-title">Records</p>
        <a href="#" className="sidebar-link">View Details</a>
        <a href="#" className="sidebar-link">Manage Users</a>
        
        <p className="sidebar-title">Settings</p>
        <a href="#" className="sidebar-link">Profile</a>
      </aside>

      {/* MAIN CONTENT SECTION */}
      <main className="dashboard-main">
        <div className="dash-welcome">
          <h2>Admin Dashboard</h2>
          <p>WanderLog Management System | Project 48</p>
        </div>

        {/* STATS CARDS */}
        <div className="chart-section">
          <div className="chart-card">
            <h3>📊 Monthly Traffic</h3>
            <div className="bar-chart">
              {/* These classes match your CSS bar heights */}
              <div className="bar bar-apr"></div>
              <div className="bar bar-may"></div>
              <div className="bar bar-jun"></div>
            </div>
          </div>
        </div>

        {/* DATA TABLE */}
        <div className="table-container">
          <h3>📋 Recent Database Records</h3>
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Destination</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>048-A</td>
                <td>Hunza Valley</td>
                <td><span className="badge active">Active</span></td>
              </tr>
              <tr>
                <td>048-B</td>
                <td>Skardu Resort</td>
                <td><span className="badge active">Active</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}