import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="nav-link">Home</Link>
      <Link to="/dashboard" className="nav-link">Dashboard</Link>
      <Link to="/destinations" className="nav-link">Destinations</Link>
      <Link to="/login" className="nav-link">Login</Link>
      <Link to="/signup" className="nav-link">Sign Up</Link>
    </nav>
  );
}