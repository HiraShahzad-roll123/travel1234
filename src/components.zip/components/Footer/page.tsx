const Footer = () => {
    
  return (
    <footer className="main-footer">
      <p>&copy; 2026 WanderLog Travel Blog. All rights reserved. | Project 48</p>
    </footer>
  );
};

export default Footer;